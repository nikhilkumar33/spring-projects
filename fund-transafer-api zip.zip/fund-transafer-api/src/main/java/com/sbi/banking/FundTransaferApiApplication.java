package com.sbi.banking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FundTransaferApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FundTransaferApiApplication.class, args);
	}

}
