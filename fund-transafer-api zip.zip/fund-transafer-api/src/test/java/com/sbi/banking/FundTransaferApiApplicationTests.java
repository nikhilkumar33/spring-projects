package com.sbi.banking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FundTransaferApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
